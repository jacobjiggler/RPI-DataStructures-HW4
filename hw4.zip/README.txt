HOMEWORK 4: PREFERENCE LISTS


NAME:  Jacob Martin


TIME SPENT ON THIS ASSIGNMENT:  14 hours


COLLABORATORS: 
You must do this assignment on your own, as described in the DS
Academic Integrity Policy.  If you did discuss the problem or error
messages, etc. with anyone, please list their names here.



ORDER NOTATION:


add_school O(n)

insert_student_into_school_preference_list O(n)^2

print_school_preferences O(n)^2

add_student O(n)

remove_school_from_student_preference_list O(n)

print_student_preferences O(n)^2

perform_matching O(n)^4

print_school_enrollments O(n)^2

print_student_decisions O(n)^2



MISC. COMMENTS TO GRADER:  
Optional, please be concise!


